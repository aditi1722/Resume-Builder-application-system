// ResumeBuilder.js
import React, { useState } from 'react';
import './ResumeBuilder.css';

const ResumeBuilder = () => {
  const [formData, setFormData] = useState({
    summary: '',
    education: '',
    skills: '',
    careerObjective: '',
    experience: '',
    achievements: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="resume-builder-container">
      <form onSubmit={handleSubmit}>
        <h2>Resume Builder</h2>
        
        <div className="form-group">
          <label>Professional Summary:</label>
          <textarea
            name="summary"
            value={formData.summary}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Education Qualifications:</label>
          <textarea
            name="education"
            value={formData.education}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Academic and Non-Academic Skills:</label>
          <textarea
            name="skills"
            value={formData.skills}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Career Objective:</label>
          <textarea
            name="careerObjective"
            value={formData.careerObjective}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Experience and Internships:</label>
          <textarea
            name="experience"
            value={formData.experience}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Skills and Achievements:</label>
          <textarea
            name="achievements"
            value={formData.achievements}
            onChange={handleChange}
          />
        </div>

        <button type="submit">Generate Resume</button>
      </form>

      {submitted && (
        <div className="resume-preview">
          <h2>Resume Preview</h2>
          <p><strong>Professional Summary:</strong> {formData.summary}</p>
          <p><strong>Education Qualifications:</strong> {formData.education}</p>
          <p><strong>Academic and Non-Academic Skills:</strong> {formData.skills}</p>
          <p><strong>Career Objective:</strong> {formData.careerObjective}</p>
          <p><strong>Experience and Internships:</strong> {formData.experience}</p>
          <p><strong>Skills and Achievements:</strong> {formData.achievements}</p>
        </div>
      )}
    </div>
  );
};

export default ResumeBuilder;
