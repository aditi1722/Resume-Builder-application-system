// App.js
import React from 'react';
import ResumeBuilder from './ResumeBuilder';

function App() {
  return (
    <div className="App">
      <ResumeBuilder />
    </div>
  );
}

export default App;

